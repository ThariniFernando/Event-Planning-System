// Function to show the success popup
function showSuccessPopup() {
    var successPopup = document.getElementById("success-popup");
    successPopup.style.display = "block";
}

// Function to close the success popup
function closeSuccessPopup() {
    var successPopup = document.getElementById("success-popup");
    successPopup.style.display = "none";
}
